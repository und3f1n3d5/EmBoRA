# Validation report

Run dir: `/mnt/data/work_isdg/final_runs/20260521_093848_quick_S0_reported_runs_compat`

- **run_dir**: /mnt/data/work_isdg/final_runs/20260521_093848_quick_S0_reported_runs_compat
- **missing_files**: []
- **round_rows**: 10
- **episode_rows**: 1
- **mood_out_of_range**: 0
- **fatigue_out_of_range**: 0
- **nan_or_inf_cells**: 0
- **duplicate_observe_count**: 0
- **fallback_rows**: 0
- **passed**: True